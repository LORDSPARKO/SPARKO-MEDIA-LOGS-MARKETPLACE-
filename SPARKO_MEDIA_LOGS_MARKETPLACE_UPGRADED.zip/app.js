async function loadProducts(){
  let { data } = await supabase.from('products').select('*');

  let container = document.getElementById('products');
  container.innerHTML = "";

  data.forEach(p=>{
    let div = document.createElement('div');
    div.className = "card";

    div.innerHTML = `
      <h3>${p.name}</h3>
      <p>₦${p.price}</p>
      <button onclick="buy('${p.name}','${p.price}')">Buy Now</button>
    `;

    container.appendChild(div);
  });
}

async function buy(name, price){
  let ref = "SPK" + Math.floor(Math.random()*999999);

  await supabase.from('orders').insert([
    { product_name:name, price:price, reference:ref }
  ]);

  alert("Order placed! Ref: " + ref + " (Proceed to payment)");
}

loadProducts();
