const supabaseUrl = "YOUR_PROJECT_URL";
const supabaseKey = "YOUR_ANON_KEY";
const supabase = supabase.createClient(supabaseUrl, supabaseKey);
